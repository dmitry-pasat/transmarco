# Version 1.0

This is the list of changes for the Version 1.0 release series.

## Version 1.0.3

* Only look for Git repository in the supplied path (and not in its parent directories).

## Version 1.0.2

* Errors from `exec()`uting the Git command are now suppressed.

## Version 1.0.1

* Fixed #2: `getVersion()` fails on Windows.

## Version 1.0.0

* Initial release.
