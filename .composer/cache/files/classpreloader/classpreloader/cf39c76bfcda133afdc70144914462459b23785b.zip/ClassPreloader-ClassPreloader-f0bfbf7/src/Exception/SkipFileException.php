<?php

namespace ClassPreloader\Exception;

use Exception;

/**
 * This is the skip file exception class.
 */
class SkipFileException extends Exception
{
    //
}
