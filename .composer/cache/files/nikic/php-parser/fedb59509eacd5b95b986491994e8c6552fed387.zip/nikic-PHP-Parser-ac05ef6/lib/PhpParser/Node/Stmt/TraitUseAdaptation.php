<?php

namespace PhpParser\Node\Stmt;

use PhpParser\Node;

/**
 * @property Node\Name $trait  Trait name
 * @property string    $method Method name
 */
abstract class TraitUseAdaptation extends Node\Stmt
{
}