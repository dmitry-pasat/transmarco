Text_Template 1.2
=================

This is the list of changes for the Text_Template 1.2 release series.

Text_Template 1.2.0
-------------------

* Added support for arbitrary delimiters for template variables.
